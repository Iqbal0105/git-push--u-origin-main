<?php
http_response_code(404);
echo "<h1>404 Not Found</h1>";
echo "<p>The requested resource was not found.</p>";
?>