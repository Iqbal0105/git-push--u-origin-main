<h1>Welcome to PhantomRFI CTF</h1>
<p>Challenge: Try to read the flag!</p>